
public class HOLAMUNDO {

	public static void main(String[] args) {
		System.out.println ("HOLA MUNDO");
		
		// TODO Auto-generated method stub

	}

}
